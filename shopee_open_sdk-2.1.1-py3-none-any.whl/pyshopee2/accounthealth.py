from .base import BaseModule


class AccountHealth(BaseModule):
    def get_late_orders(self, **kwargs):
        """v2.account_health.get_late_orders (GET)"""
        return self.client.call(module="account_health", name="get_late_orders", payload=kwargs)

    def get_listings_with_issues(self, **kwargs):
        """v2.account_health.get_listings_with_issues (GET)"""
        return self.client.call(module="account_health", name="get_listings_with_issues", payload=kwargs)

    def get_metric_source_detail(self, **kwargs):
        """v2.account_health.get_metric_source_detail (GET)"""
        return self.client.call(module="account_health", name="get_metric_source_detail", payload=kwargs)

    def get_penalty_point_history(self, **kwargs):
        """v2.account_health.get_penalty_point_history (GET)"""
        return self.client.call(module="account_health", name="get_penalty_point_history", payload=kwargs)

    def get_punishment_history(self, **kwargs):
        """v2.account_health.get_punishment_history (GET)"""
        return self.client.call(module="account_health", name="get_punishment_history", payload=kwargs)

    def get_shop_performance(self, **kwargs):
        """v2.account_health.get_shop_performance (GET)"""
        return self.client.call(module="account_health", name="get_shop_performance", payload=kwargs)
