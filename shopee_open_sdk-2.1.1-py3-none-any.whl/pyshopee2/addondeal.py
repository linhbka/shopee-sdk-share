from .base import BaseModule


class AddonDeal(BaseModule):
    def add_add_on_deal(self, **kwargs):
        """v2.add_on_deal.add_add_on_deal (POST)"""
        return self.client.call(module="add_on_deal", name="add_add_on_deal", payload=kwargs)

    def add_add_on_deal_main_item(self, **kwargs):
        """v2.add_on_deal.add_add_on_deal_main_item (POST)"""
        return self.client.call(module="add_on_deal", name="add_add_on_deal_main_item", payload=kwargs)

    def add_add_on_deal_sub_item(self, **kwargs):
        """v2.add_on_deal.add_add_on_deal_sub_item (POST)"""
        return self.client.call(module="add_on_deal", name="add_add_on_deal_sub_item", payload=kwargs)

    def delete_add_on_deal(self, **kwargs):
        """v2.add_on_deal.delete_add_on_deal (POST)"""
        return self.client.call(module="add_on_deal", name="delete_add_on_deal", payload=kwargs)

    def delete_add_on_deal_main_item(self, **kwargs):
        """v2.add_on_deal.delete_add_on_deal_main_item (POST)"""
        return self.client.call(module="add_on_deal", name="delete_add_on_deal_main_item", payload=kwargs)

    def delete_add_on_deal_sub_item(self, **kwargs):
        """v2.add_on_deal.delete_add_on_deal_sub_item (POST)"""
        return self.client.call(module="add_on_deal", name="delete_add_on_deal_sub_item", payload=kwargs)

    def end_add_on_deal(self, **kwargs):
        """v2.add_on_deal.end_add_on_deal (POST)"""
        return self.client.call(module="add_on_deal", name="end_add_on_deal", payload=kwargs)

    def get_add_on_deal(self, **kwargs):
        """v2.add_on_deal.get_add_on_deal (GET)"""
        return self.client.call(module="add_on_deal", name="get_add_on_deal", payload=kwargs)

    def get_add_on_deal_list(self, **kwargs):
        """v2.add_on_deal.get_add_on_deal_list (GET)"""
        return self.client.call(module="add_on_deal", name="get_add_on_deal_list", payload=kwargs)

    def get_add_on_deal_main_item(self, **kwargs):
        """v2.add_on_deal.get_add_on_deal_main_item (GET)"""
        return self.client.call(module="add_on_deal", name="get_add_on_deal_main_item", payload=kwargs)

    def get_add_on_deal_sub_item(self, **kwargs):
        """v2.add_on_deal.get_add_on_deal_sub_item (GET)"""
        return self.client.call(module="add_on_deal", name="get_add_on_deal_sub_item", payload=kwargs)

    def update_add_on_deal(self, **kwargs):
        """v2.add_on_deal.update_add_on_deal (POST)"""
        return self.client.call(module="add_on_deal", name="update_add_on_deal", payload=kwargs)

    def update_add_on_deal_main_item(self, **kwargs):
        """v2.add_on_deal.update_add_on_deal_main_item (POST)"""
        return self.client.call(module="add_on_deal", name="update_add_on_deal_main_item", payload=kwargs)

    def update_add_on_deal_sub_item(self, **kwargs):
        """v2.add_on_deal.update_add_on_deal_sub_item (POST)"""
        return self.client.call(module="add_on_deal", name="update_add_on_deal_sub_item", payload=kwargs)
