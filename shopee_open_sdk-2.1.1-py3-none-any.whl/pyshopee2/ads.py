from .base import BaseModule


class Ads(BaseModule):
    def check_create_gms_product_campaign_eligibility(self, **kwargs):
        """v2.ads.check_create_gms_product_campaign_eligibility (GET)"""
        return self.client.call(module="ads", name="check_create_gms_product_campaign_eligibility", payload=kwargs)

    def create_auto_product_ads(self, **kwargs):
        """v2.ads.create_auto_product_ads (POST)"""
        return self.client.call(module="ads", name="create_auto_product_ads", payload=kwargs)

    def create_gms_product_campaign(self, **kwargs):
        """v2.ads.create_gms_product_campaign (POST)"""
        return self.client.call(module="ads", name="create_gms_product_campaign", payload=kwargs)

    def create_manual_product_ads(self, **kwargs):
        """v2.ads.create_manual_product_ads (POST)"""
        return self.client.call(module="ads", name="create_manual_product_ads", payload=kwargs)

    def edit_auto_product_ads(self, **kwargs):
        """v2.ads.edit_auto_product_ads (POST)"""
        return self.client.call(module="ads", name="edit_auto_product_ads", payload=kwargs)

    def edit_gms_item_product_campaign(self, **kwargs):
        """v2.ads.edit_gms_item_product_campaign (POST)"""
        return self.client.call(module="ads", name="edit_gms_item_product_campaign", payload=kwargs)

    def edit_gms_product_campaign(self, **kwargs):
        """v2.ads.edit_gms_product_campaign (POST)"""
        return self.client.call(module="ads", name="edit_gms_product_campaign", payload=kwargs)

    def edit_manual_product_ad_keywords(self, **kwargs):
        """v2.ads.edit_manual_product_ad_keywords (POST)"""
        return self.client.call(module="ads", name="edit_manual_product_ad_keywords", payload=kwargs)

    def edit_manual_product_ads(self, **kwargs):
        """v2.ads.edit_manual_product_ads (POST)"""
        return self.client.call(module="ads", name="edit_manual_product_ads", payload=kwargs)

    def get_ads_fácil_shop_rate(self, **kwargs):
        """v2.ads.get_ads_fácil_shop_rate (GET)"""
        return self.client.call(module="ads", name="get_ads_fácil_shop_rate", payload=kwargs)

    def get_all_cpc_ads_daily_performance(self, **kwargs):
        """v2.ads.get_all_cpc_ads_daily_performance (GET)"""
        return self.client.call(module="ads", name="get_all_cpc_ads_daily_performance", payload=kwargs)

    def get_all_cpc_ads_hourly_performance(self, **kwargs):
        """v2.ads.get_all_cpc_ads_hourly_performance (GET)"""
        return self.client.call(module="ads", name="get_all_cpc_ads_hourly_performance", payload=kwargs)

    def get_create_product_ad_budget_suggestion(self, **kwargs):
        """v2.ads.get_create_product_ad_budget_suggestion (GET)"""
        return self.client.call(module="ads", name="get_create_product_ad_budget_suggestion", payload=kwargs)

    def get_gms_campaign_performance(self, **kwargs):
        """v2.ads.get_gms_campaign_performance (POST)"""
        return self.client.call(module="ads", name="get_gms_campaign_performance", payload=kwargs)

    def get_gms_item_performance(self, **kwargs):
        """v2.ads.get_gms_item_performance (POST)"""
        return self.client.call(module="ads", name="get_gms_item_performance", payload=kwargs)

    def get_product_campaign_daily_performance(self, **kwargs):
        """v2.ads.get_product_campaign_daily_performance (GET)"""
        return self.client.call(module="ads", name="get_product_campaign_daily_performance", payload=kwargs)

    def get_product_campaign_hourly_performance(self, **kwargs):
        """v2.ads.get_product_campaign_hourly_performance (GET)"""
        return self.client.call(module="ads", name="get_product_campaign_hourly_performance", payload=kwargs)

    def get_product_level_campaign_id_list(self, **kwargs):
        """v2.ads.get_product_level_campaign_id_list (GET)"""
        return self.client.call(module="ads", name="get_product_level_campaign_id_list", payload=kwargs)

    def get_product_level_campaign_setting_info(self, **kwargs):
        """v2.ads.get_product_level_campaign_setting_info (GET)"""
        return self.client.call(module="ads", name="get_product_level_campaign_setting_info", payload=kwargs)

    def get_product_recommended_roi_target(self, **kwargs):
        """v2.ads.get_product_recommended_roi_target (GET)"""
        return self.client.call(module="ads", name="get_product_recommended_roi_target", payload=kwargs)

    def get_recommended_item_list(self, **kwargs):
        """v2.ads.get_recommended_item_list (GET)"""
        return self.client.call(module="ads", name="get_recommended_item_list", payload=kwargs)

    def get_recommended_keyword_list(self, **kwargs):
        """v2.ads.get_recommended_keyword_list (GET)"""
        return self.client.call(module="ads", name="get_recommended_keyword_list", payload=kwargs)

    def get_shop_toggle_info(self, **kwargs):
        """v2.ads.get_shop_toggle_info (GET)"""
        return self.client.call(module="ads", name="get_shop_toggle_info", payload=kwargs)

    def get_total_balance(self, **kwargs):
        """v2.ads.get_total_balance (GET)"""
        return self.client.call(module="ads", name="get_total_balance", payload=kwargs)

    def list_gms_user_deleted_item(self, **kwargs):
        """v2.ads.list_gms_user_deleted_item (POST)"""
        return self.client.call(module="ads", name="list_gms_user_deleted_item", payload=kwargs)
