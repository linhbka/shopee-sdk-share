from .base import BaseModule


class Ams(BaseModule):
    def add_all_products_to_open_campaign(self, **kwargs):
        """v2.ams.add_all_products_to_open_campaign (POST)"""
        return self.client.call(module="ams", name="add_all_products_to_open_campaign", payload=kwargs)

    def batch_add_products_to_open_campaign(self, **kwargs):
        """v2.ams.batch_add_products_to_open_campaign (POST)"""
        return self.client.call(module="ams", name="batch_add_products_to_open_campaign", payload=kwargs)

    def batch_edit_products_open_campaign_setting(self, **kwargs):
        """v2.ams.batch_edit_products_open_campaign_setting (POST)"""
        return self.client.call(module="ams", name="batch_edit_products_open_campaign_setting", payload=kwargs)

    def batch_get_products_suggested_rate(self, **kwargs):
        """v2.ams.batch_get_products_suggested_rate (GET)"""
        return self.client.call(module="ams", name="batch_get_products_suggested_rate", payload=kwargs)

    def batch_remove_products_open_campaign_setting(self, **kwargs):
        """v2.ams.batch_remove_products_open_campaign_setting (POST)"""
        return self.client.call(module="ams", name="batch_remove_products_open_campaign_setting", payload=kwargs)

    def create_new_targeted_campaign(self, **kwargs):
        """v2.ams.create_new_targeted_campaign (POST)"""
        return self.client.call(module="ams", name="create_new_targeted_campaign", payload=kwargs)

    def edit_affiliate_list_of_targeted_campaign(self, **kwargs):
        """v2.ams.edit_affiliate_list_of_targeted_campaign (POST)"""
        return self.client.call(module="ams", name="edit_affiliate_list_of_targeted_campaign", payload=kwargs)

    def edit_all_products_open_campaign_setting(self, **kwargs):
        """v2.ams.edit_all_products_open_campaign_setting (POST)"""
        return self.client.call(module="ams", name="edit_all_products_open_campaign_setting", payload=kwargs)

    def edit_product_list_of_targeted_campaign(self, **kwargs):
        """v2.ams.edit_product_list_of_targeted_campaign (POST)"""
        return self.client.call(module="ams", name="edit_product_list_of_targeted_campaign", payload=kwargs)

    def get_affiliate_performance(self, **kwargs):
        """v2.ams.get_affiliate_performance (GET)"""
        return self.client.call(module="ams", name="get_affiliate_performance", payload=kwargs)

    def get_auto_add_new_product_toggle_status(self, **kwargs):
        """v2.ams.get_auto_add_new_product_toggle_status (GET)"""
        return self.client.call(module="ams", name="get_auto_add_new_product_toggle_status", payload=kwargs)

    def get_campaign_key_metrics_performance(self, **kwargs):
        """v2.ams.get_campaign_key_metrics_performance (GET)"""
        return self.client.call(module="ams", name="get_campaign_key_metrics_performance", payload=kwargs)

    def get_content_performance(self, **kwargs):
        """v2.ams.get_content_performance (GET)"""
        return self.client.call(module="ams", name="get_content_performance", payload=kwargs)

    def get_conversion_report(self, **kwargs):
        """v2.ams.get_conversion_report (GET)"""
        return self.client.call(module="ams", name="get_conversion_report", payload=kwargs)

    def get_managed_affiliate_list(self, **kwargs):
        """v2.ams.get_managed_affiliate_list (GET)"""
        return self.client.call(module="ams", name="get_managed_affiliate_list", payload=kwargs)

    def get_open_campaign_added_product(self, **kwargs):
        """v2.ams.get_open_campaign_added_product (GET)"""
        return self.client.call(module="ams", name="get_open_campaign_added_product", payload=kwargs)

    def get_open_campaign_batch_task_result(self, **kwargs):
        """v2.ams.get_open_campaign_batch_task_result (GET)"""
        return self.client.call(module="ams", name="get_open_campaign_batch_task_result", payload=kwargs)

    def get_open_campaign_not_added_product(self, **kwargs):
        """v2.ams.get_open_campaign_not_added_product (GET)"""
        return self.client.call(module="ams", name="get_open_campaign_not_added_product", payload=kwargs)

    def get_open_campaign_performance(self, **kwargs):
        """v2.ams.get_open_campaign_performance (GET)"""
        return self.client.call(module="ams", name="get_open_campaign_performance", payload=kwargs)

    def get_optimization_suggestion_product(self, **kwargs):
        """v2.ams.get_optimization_suggestion_product (GET)"""
        return self.client.call(module="ams", name="get_optimization_suggestion_product", payload=kwargs)

    def get_performance_data_update_time(self, **kwargs):
        """v2.ams.get_performance_data_update_time (GET)"""
        return self.client.call(module="ams", name="get_performance_data_update_time", payload=kwargs)

    def get_product_performance(self, **kwargs):
        """v2.ams.get_product_performance (GET)"""
        return self.client.call(module="ams", name="get_product_performance", payload=kwargs)

    def get_recommended_affiliate_list(self, **kwargs):
        """v2.ams.get_recommended_affiliate_list (GET)"""
        return self.client.call(module="ams", name="get_recommended_affiliate_list", payload=kwargs)

    def get_shop_performance(self, **kwargs):
        """v2.ams.get_shop_performance (GET)"""
        return self.client.call(module="ams", name="get_shop_performance", payload=kwargs)

    def get_shop_suggested_rate(self, **kwargs):
        """v2.ams.get_shop_suggested_rate (GET)"""
        return self.client.call(module="ams", name="get_shop_suggested_rate", payload=kwargs)

    def get_targeted_campaign_addable_product_list(self, **kwargs):
        """v2.ams.get_targeted_campaign_addable_product_list (GET)"""
        return self.client.call(module="ams", name="get_targeted_campaign_addable_product_list", payload=kwargs)

    def get_targeted_campaign_list(self, **kwargs):
        """v2.ams.get_targeted_campaign_list (GET)"""
        return self.client.call(module="ams", name="get_targeted_campaign_list", payload=kwargs)

    def get_targeted_campaign_performance(self, **kwargs):
        """v2.ams.get_targeted_campaign_performance (GET)"""
        return self.client.call(module="ams", name="get_targeted_campaign_performance", payload=kwargs)

    def get_targeted_campaign_settings(self, **kwargs):
        """v2.ams.get_targeted_campaign_settings (GET)"""
        return self.client.call(module="ams", name="get_targeted_campaign_settings", payload=kwargs)

    def get_validation_list(self, **kwargs):
        """v2.ams.get_validation_list (GET)"""
        return self.client.call(module="ams", name="get_validation_list", payload=kwargs)

    def get_validation_report(self, **kwargs):
        """v2.ams.get_validation_report (GET)"""
        return self.client.call(module="ams", name="get_validation_report", payload=kwargs)

    def query_affiliate_list(self, **kwargs):
        """v2.ams.query_affiliate_list (GET)"""
        return self.client.call(module="ams", name="query_affiliate_list", payload=kwargs)

    def remove_all_products_open_campaign_setting(self, **kwargs):
        """v2.ams.remove_all_products_open_campaign_setting (POST)"""
        return self.client.call(module="ams", name="remove_all_products_open_campaign_setting", payload=kwargs)

    def terminate_targeted_campaign(self, **kwargs):
        """v2.ams.terminate_targeted_campaign (POST)"""
        return self.client.call(module="ams", name="terminate_targeted_campaign", payload=kwargs)

    def update_auto_add_new_product_setting(self, **kwargs):
        """v2.ams.update_auto_add_new_product_setting (POST)"""
        return self.client.call(module="ams", name="update_auto_add_new_product_setting", payload=kwargs)

    def update_basic_info_of_targeted_campaign(self, **kwargs):
        """v2.ams.update_basic_info_of_targeted_campaign (POST)"""
        return self.client.call(module="ams", name="update_basic_info_of_targeted_campaign", payload=kwargs)
