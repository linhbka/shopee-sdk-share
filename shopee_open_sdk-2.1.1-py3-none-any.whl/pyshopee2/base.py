class BaseModule(object):
    """
        shopee base api
    """
    def __init__(self, client):
        self.client = client

    def call(self, name, **kwargs):
        return self.client.call(name=name, payload=kwargs)

    def __getattr__(self, name):
        def _caller(**kwargs):
            return self.client.call(module=self.__class__.__name__.lower(), name=name, payload=kwargs)

        return _caller


