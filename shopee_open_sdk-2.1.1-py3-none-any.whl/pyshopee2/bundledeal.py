from .base import BaseModule


class BundleDeal(BaseModule):
    def add_bundle_deal(self, **kwargs):
        """v2.bundle_deal.add_bundle_deal (POST)"""
        return self.client.call(module="bundle_deal", name="add_bundle_deal", payload=kwargs)

    def add_bundle_deal_item(self, **kwargs):
        """v2.bundle_deal.add_bundle_deal_item (POST)"""
        return self.client.call(module="bundle_deal", name="add_bundle_deal_item", payload=kwargs)

    def delete_bundle_deal(self, **kwargs):
        """v2.bundle_deal.delete_bundle_deal (POST)"""
        return self.client.call(module="bundle_deal", name="delete_bundle_deal", payload=kwargs)

    def delete_bundle_deal_item(self, **kwargs):
        """v2.bundle_deal.delete_bundle_deal_item (POST)"""
        return self.client.call(module="bundle_deal", name="delete_bundle_deal_item", payload=kwargs)

    def end_bundle_deal(self, **kwargs):
        """v2.bundle_deal.end_bundle_deal (POST)"""
        return self.client.call(module="bundle_deal", name="end_bundle_deal", payload=kwargs)

    def get_bundle_deal(self, **kwargs):
        """v2.bundle_deal.get_bundle_deal (GET)"""
        return self.client.call(module="bundle_deal", name="get_bundle_deal", payload=kwargs)

    def get_bundle_deal_item(self, **kwargs):
        """v2.bundle_deal.get_bundle_deal_item (GET)"""
        return self.client.call(module="bundle_deal", name="get_bundle_deal_item", payload=kwargs)

    def get_bundle_deal_list(self, **kwargs):
        """v2.bundle_deal.get_bundle_deal_list (GET)"""
        return self.client.call(module="bundle_deal", name="get_bundle_deal_list", payload=kwargs)

    def update_bundle_deal(self, **kwargs):
        """v2.bundle_deal.update_bundle_deal (POST)"""
        return self.client.call(module="bundle_deal", name="update_bundle_deal", payload=kwargs)

    def update_bundle_deal_item(self, **kwargs):
        """v2.bundle_deal.update_bundle_deal_item (POST)"""
        return self.client.call(module="bundle_deal", name="update_bundle_deal_item", payload=kwargs)
