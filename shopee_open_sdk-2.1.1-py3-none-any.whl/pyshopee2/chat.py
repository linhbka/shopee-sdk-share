from .base import BaseModule
from .exceptions import EndpointNotFoundError


class Chat(BaseModule):
    def __getattr__(self, name):
        raise EndpointNotFoundError(
            "Shopee v2 no longer exposes 'sellerchat' module in current Open API docs. "
            "Use client.ams.* endpoints if you are integrating affiliate marketing service APIs."
        )
