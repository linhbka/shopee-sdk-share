import hashlib
import hmac
import json
import time
from pathlib import Path

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None

from .accounthealth import AccountHealth
from .addondeal import AddonDeal
from .base import BaseModule
from .bundledeal import BundleDeal
from .chat import Chat
from .discount import Discount
from .exceptions import ShopeeRequestError
from .fbs import Fbs
from .firstmile import FirstMile
from .followprize import FollowPrize
from .globalproduct import GlobalProduct
from .livestream import Livestream
from .logistics import Logistics
from .media import Media
from .mediaspace import MediaSpace
from .merchant import Merchant
from .order import Order
from .payment import Payment
from .product import Product
from .public import Public
from .push import Push
from .registry import EndpointRegistry
from .returns import Returns
from .sbs import Sbs
from .shop import Shop
from .shopcategory import ShopCategory
from .shopflashsale import ShopFlashSale
from .toppicks import Toppicks
from .video import Video
from .voucher import Voucher
from .ads import Ads
from .ams import Ams

registered_module = {
    "product": Product,
    "mediaspace": MediaSpace,
    "shop": Shop,
    "merchant": Merchant,
    "order": Order,
    "logistics": Logistics,
    "firstmile": FirstMile,
    "payment": Payment,
    "discount": Discount,
    "fbs": Fbs,
    "bundledeal": BundleDeal,
    "addondeal": AddonDeal,
    "voucher": Voucher,
    "followprize": FollowPrize,
    "globalproduct": GlobalProduct,
    "global_product": GlobalProduct,
    "toppicks": Toppicks,
    "livestream": Livestream,
    "returns": Returns,
    "media": Media,
    "accounthealth": AccountHealth,
    "chat": Chat,
    "public": Public,
    "push": Push,
    "sbs": Sbs,
    "shopcategory": ShopCategory,
    "shop_category": ShopCategory,
    "shopflashsale": ShopFlashSale,
    "shop_flash_sale": ShopFlashSale,
    "video": Video,
    "ads": Ads,
    "ams": Ams,
}


class ClientMeta(type):
    def __new__(mcs, name, bases, dct):
        klass = super(ClientMeta, mcs).__new__(mcs, name, bases, dct)
        setattr(klass, "registered_module", registered_module)
        return klass


class Client(object, metaclass=ClientMeta):
    BASE_URL = "https://openplatform.shopee.com"
    BASE_TEST_URL = "https://openplatform.sandbox.test-stable.shopee.sg"
    AUTH_TOKEN_PATH = "/api/v2/auth/token/get"
    AUTH_ACCESS_TOKEN_PATH = "/api/v2/auth/access_token/get"
    DEFAULT_TIMEOUT = 30

    def __init__(
        self,
        shop_id,
        partner_id,
        partner_key,
        redirect_url,
        test_env=False,
        code=None,
        access_token=None,
        refresh_token=None,
        merchant_id=None,
        supplier_id=None,
        user_id=None,
        base_url=None,
        timeout=DEFAULT_TIMEOUT,
        session=None,
    ):
        self.partner_id = int(partner_id)
        self.partner_key = partner_key
        self.redirect_url = redirect_url
        self.shop_id = int(shop_id) if shop_id is not None else None
        self.code = code
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.merchant_id = merchant_id
        self.supplier_id = supplier_id
        self.user_id = user_id
        self.timeout = timeout
        self.CACHED_MODULE = {}

        if base_url:
            self.host = base_url.rstrip("/")
        elif test_env:
            self.host = self.BASE_TEST_URL
        else:
            self.host = self.BASE_URL

        registry_path = Path(__file__).with_name("endpoint_registry.json")
        self.registry = EndpointRegistry.from_file(registry_path)
        if session is not None:
            self.session = session
        elif requests is None:
            raise ImportError("requests package is required. Install with: pip install requests")
        else:
            self.session = requests.Session()

    def __repr__(self):
        return f"<{self.__class__.__name__} partner_id={self.partner_id} shop_id={self.shop_id} test_env={self.host == self.BASE_TEST_URL}>"

    def __str__(self):
        return self.__repr__()

    def __getattr__(self, name):
        try:
            return super(Client, self).__getattribute__(name)
        except AttributeError as original_error:
            module = self._get_cached_module(name)
            if module is not None:
                return module
            resolved = self.registry.resolve_module(name)
            if resolved:
                dynamic = DynamicModule(self, resolved)
                self.CACHED_MODULE[name] = dynamic
                return dynamic
            raise original_error

    def _get_cached_module(self, key):
        cached = self.CACHED_MODULE.get(key)
        if cached:
            return cached
        installed = self.registered_module.get(key)
        if not installed:
            return None
        cached = installed(self)
        self.CACHED_MODULE[key] = cached
        return cached

    def _make_timestamp(self):
        return int(time.time())

    def _sign(self, path, timestamp, access_token=None, identity=None):
        base = f"{self.partner_id}{path}{timestamp}"
        if access_token:
            base += str(access_token)
        if identity is not None:
            base += str(identity)
        return hmac.new(self.partner_key.encode(), base.encode(), hashlib.sha256).hexdigest()

    def _build_query(self, endpoint, timestamp, payload):
        payload = payload or {}
        query = {"partner_id": self.partner_id, "timestamp": timestamp}

        access_token = None
        identity = None
        identity_key = endpoint.get("id_key")

        if endpoint.get("requires_access_token"):
            access_token = payload.pop("access_token", None) or self.access_token
            if not access_token:
                raise ValueError(f"access_token is required for {endpoint['api_name']}")
            query["access_token"] = access_token

            if identity_key:
                identity = payload.pop(identity_key, None)
                if identity is None:
                    identity = getattr(self, identity_key, None)
                if identity is None:
                    raise ValueError(f"{identity_key} is required for {endpoint['api_name']}")
                query[identity_key] = identity

        query["sign"] = self._sign(endpoint["path"], timestamp, access_token=access_token, identity=identity)
        return query

    def _request(self, method, path, query, json_body=None, timeout=None):
        url = f"{self.host}{path}"
        response = self.session.request(
            method=method,
            url=url,
            params={k: v for k, v in query.items() if v is not None},
            json=json_body,
            timeout=timeout or self.timeout,
            verify=True,
        )

        try:
            payload = response.json()
        except json.JSONDecodeError:
            payload = {"error": "non_json_response", "message": response.text}

        if response.status_code >= 400:
            raise ShopeeRequestError(
                f"HTTP {response.status_code} calling {path}",
                status_code=response.status_code,
                error=payload.get("error"),
                request_id=payload.get("request_id"),
                payload=payload,
            )

        error_value = payload.get("error")
        if error_value:
            raise ShopeeRequestError(
                f"Shopee API error {error_value}: {payload.get('message')}",
                status_code=response.status_code,
                error=error_value,
                request_id=payload.get("request_id"),
                payload=payload,
            )

        return payload

    def call(self, name=None, module=None, payload=None, method=None, uri=None):
        payload = dict(payload or {})
        endpoint = self.registry.find(
            api_name=name if name and name.startswith("v2.") else None,
            module=module,
            function=name if module else None,
            uri=uri,
        )
        request_method = (method or endpoint.get("method") or "POST").upper()
        timestamp = self._make_timestamp()
        query = self._build_query(endpoint, timestamp, payload)

        if request_method == "GET":
            query.update(payload)
            json_body = None
        else:
            json_body = payload

        return self._request(request_method, endpoint["path"], query=query, json_body=json_body)

    def execute(self, uri, method, body=None):
        return self.call(uri=uri, method=method, payload=body or {})

    def set_access_token(self, access_token):
        self.access_token = access_token

    def auth_url(self, path):
        timestamp = self._make_timestamp()
        sign = self._sign(path, timestamp)
        url = f"{self.host}{path}?partner_id={self.partner_id}&timestamp={timestamp}&sign={sign}"
        return sign, url

    def shop_authorization(self, redirect_url=None):
        redirect = redirect_url or self.redirect_url
        _, url = self.auth_url("/api/v2/shop/auth_partner")
        return f"{url}&redirect={redirect}"

    def _call_public_auth_endpoint(self, path, body):
        timestamp = self._make_timestamp()
        sign = self._sign(path, timestamp)
        query = {"partner_id": self.partner_id, "timestamp": timestamp, "sign": sign}
        return self._request("POST", path, query=query, json_body=body)

    def get_token(self, code=None, shop_id=None):
        auth_code = code or self.code
        target_shop_id = int(shop_id or self.shop_id)
        if not auth_code:
            raise ValueError("code is required for get_token")
        if not target_shop_id:
            raise ValueError("shop_id is required for get_token")
        body = {"code": auth_code, "shop_id": target_shop_id, "partner_id": self.partner_id}
        result = self._call_public_auth_endpoint(self.AUTH_TOKEN_PATH, body)
        self.access_token = result.get("access_token")
        self.refresh_token = result.get("refresh_token")
        return self.access_token, result.get("expire_in"), self.refresh_token

    def get_access_token(self, refresh_token=None, shop_id=None, merchant_id=None, supplier_id=None, user_id=None):
        body = {
            "partner_id": self.partner_id,
            "refresh_token": refresh_token or self.refresh_token,
        }
        if shop_id or self.shop_id:
            body["shop_id"] = int(shop_id or self.shop_id)
        elif merchant_id or self.merchant_id:
            body["merchant_id"] = int(merchant_id or self.merchant_id)
        elif supplier_id or self.supplier_id:
            body["supplier_id"] = int(supplier_id or self.supplier_id)
        elif user_id or self.user_id:
            body["user_id"] = int(user_id or self.user_id)

        result = self._call_public_auth_endpoint(self.AUTH_ACCESS_TOKEN_PATH, body)
        self.access_token = result.get("access_token")
        self.refresh_token = result.get("refresh_token")
        return self.access_token, result.get("expire_in"), self.refresh_token

    def module(self, module_name):
        module_name = module_name.lower()
        cached = self._get_cached_module(module_name)
        if cached:
            return cached
        resolved = self.registry.resolve_module(module_name) or module_name
        return DynamicModule(self, resolved)


class DynamicModule(BaseModule):
    def __init__(self, client, module_name):
        super().__init__(client)
        self.module_name = module_name

    def __getattr__(self, name):
        def _caller(**kwargs):
            return self.client.call(module=self.module_name, name=name, payload=kwargs)

        return _caller
