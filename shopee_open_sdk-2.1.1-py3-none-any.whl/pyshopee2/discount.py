from .base import BaseModule


class Discount(BaseModule):
    def add_discount(self, **kwargs):
        """v2.discount.add_discount (POST)"""
        return self.client.call(module="discount", name="add_discount", payload=kwargs)

    def add_discount_item(self, **kwargs):
        """v2.discount.add_discount_item (POST)"""
        return self.client.call(module="discount", name="add_discount_item", payload=kwargs)

    def delete_discount(self, **kwargs):
        """v2.discount.delete_discount (POST)"""
        return self.client.call(module="discount", name="delete_discount", payload=kwargs)

    def delete_discount_item(self, **kwargs):
        """v2.discount.delete_discount_item (POST)"""
        return self.client.call(module="discount", name="delete_discount_item", payload=kwargs)

    def delete_sip_discount(self, **kwargs):
        """v2.discount.delete_sip_discount (POST)"""
        return self.client.call(module="discount", name="delete_sip_discount", payload=kwargs)

    def end_discount(self, **kwargs):
        """v2.discount.end_discount (POST)"""
        return self.client.call(module="discount", name="end_discount", payload=kwargs)

    def get_discount(self, **kwargs):
        """v2.discount.get_discount (GET)"""
        return self.client.call(module="discount", name="get_discount", payload=kwargs)

    def get_discount_list(self, **kwargs):
        """v2.discount.get_discount_list (GET)"""
        return self.client.call(module="discount", name="get_discount_list", payload=kwargs)

    def get_sip_discounts(self, **kwargs):
        """v2.discount.get_sip_discounts (GET)"""
        return self.client.call(module="discount", name="get_sip_discounts", payload=kwargs)

    def set_sip_discount(self, **kwargs):
        """v2.discount.set_sip_discount (POST)"""
        return self.client.call(module="discount", name="set_sip_discount", payload=kwargs)

    def update_discount(self, **kwargs):
        """v2.discount.update_discount (POST)"""
        return self.client.call(module="discount", name="update_discount", payload=kwargs)

    def update_discount_item(self, **kwargs):
        """v2.discount.update_discount_item (POST)"""
        return self.client.call(module="discount", name="update_discount_item", payload=kwargs)
