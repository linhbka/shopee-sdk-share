class ShopeeError(Exception):
    pass


class EndpointNotFoundError(ShopeeError):
    pass


class ShopeeRequestError(ShopeeError):
    def __init__(self, message, status_code=None, error=None, request_id=None, payload=None):
        super().__init__(message)
        self.status_code = status_code
        self.error = error
        self.request_id = request_id
        self.payload = self._mask_payload(payload or {})

    def _mask_payload(self, data):
        if not isinstance(data, dict):
            return data
        masked = data.copy()
        for key in ["access_token", "refresh_token", "partner_key", "sign"]:
            if key in masked:
                masked[key] = "***MASKED***"
        return masked

    def __repr__(self):
        return f"<{self.__class__.__name__} status_code={self.status_code} error={self.error} request_id={self.request_id}>"

