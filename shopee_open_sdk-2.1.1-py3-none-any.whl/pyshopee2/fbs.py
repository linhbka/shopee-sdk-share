from .base import BaseModule


class Fbs(BaseModule):
    def query_br_shop_block_status(self, **kwargs):
        """v2.fbs.query_br_shop_block_status (GET)"""
        return self.client.call(module="fbs", name="query_br_shop_block_status", payload=kwargs)

    def query_br_shop_enrollment_status(self, **kwargs):
        """v2.fbs.query_br_shop_enrollment_status (GET)"""
        return self.client.call(module="fbs", name="query_br_shop_enrollment_status", payload=kwargs)

    def query_br_shop_invoice_error(self, **kwargs):
        """v2.fbs.query_br_shop_invoice_error (GET)"""
        return self.client.call(module="fbs", name="query_br_shop_invoice_error", payload=kwargs)

    def query_br_sku_block_status(self, **kwargs):
        """v2.fbs.query_br_sku_block_status (GET)"""
        return self.client.call(module="fbs", name="query_br_sku_block_status", payload=kwargs)
