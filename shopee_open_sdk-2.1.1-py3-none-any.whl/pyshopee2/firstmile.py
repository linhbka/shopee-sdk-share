from .base import BaseModule


class FirstMile(BaseModule):
    def bind_courier_delivery_first_mile_tracking_number(self, **kwargs):
        """v2.first_mile.bind_courier_delivery_first_mile_tracking_number (POST)"""
        return self.client.call(module="first_mile", name="bind_courier_delivery_first_mile_tracking_number", payload=kwargs)

    def bind_first_mile_tracking_number(self, **kwargs):
        """v2.first_mile.bind_first_mile_tracking_number (POST)"""
        return self.client.call(module="first_mile", name="bind_first_mile_tracking_number", payload=kwargs)

    def generate_and_bind_first_mile_tracking_number(self, **kwargs):
        """v2.first_mile.generate_and_bind_first_mile_tracking_number (POST)"""
        return self.client.call(module="first_mile", name="generate_and_bind_first_mile_tracking_number", payload=kwargs)

    def generate_first_mile_tracking_number(self, **kwargs):
        """v2.first_mile.generate_first_mile_tracking_number (POST)"""
        return self.client.call(module="first_mile", name="generate_first_mile_tracking_number", payload=kwargs)

    def get_channel_list(self, **kwargs):
        """v2.first_mile.get_channel_list (GET)"""
        return self.client.call(module="first_mile", name="get_channel_list", payload=kwargs)

    def get_courier_delivery_channel_list(self, **kwargs):
        """v2.first_mile.get_courier_delivery_channel_list (GET)"""
        return self.client.call(module="first_mile", name="get_courier_delivery_channel_list", payload=kwargs)

    def get_courier_delivery_detail(self, **kwargs):
        """v2.first_mile.get_courier_delivery_detail (GET)"""
        return self.client.call(module="first_mile", name="get_courier_delivery_detail", payload=kwargs)

    def get_courier_delivery_tracking_number_list(self, **kwargs):
        """v2.first_mile.get_courier_delivery_tracking_number_list (POST)"""
        return self.client.call(module="first_mile", name="get_courier_delivery_tracking_number_list", payload=kwargs)

    def get_courier_delivery_waybill(self, **kwargs):
        """v2.first_mile.get_courier_delivery_waybill (POST)"""
        return self.client.call(module="first_mile", name="get_courier_delivery_waybill", payload=kwargs)

    def get_detail(self, **kwargs):
        """v2.first_mile.get_detail (GET)"""
        return self.client.call(module="first_mile", name="get_detail", payload=kwargs)

    def get_tracking_number_list(self, **kwargs):
        """v2.first_mile.get_tracking_number_list (GET)"""
        return self.client.call(module="first_mile", name="get_tracking_number_list", payload=kwargs)

    def get_transit_warehouse_list(self, **kwargs):
        """v2.first_mile.get_transit_warehouse_list (GET)"""
        return self.client.call(module="first_mile", name="get_transit_warehouse_list", payload=kwargs)

    def get_unbind_order_list(self, **kwargs):
        """v2.first_mile.get_unbind_order_list (GET)"""
        return self.client.call(module="first_mile", name="get_unbind_order_list", payload=kwargs)

    def get_waybill(self, **kwargs):
        """v2.first_mile.get_waybill (POST)"""
        return self.client.call(module="first_mile", name="get_waybill", payload=kwargs)

    def unbind_first_mile_tracking_number(self, **kwargs):
        """v2.first_mile.unbind_first_mile_tracking_number (POST)"""
        return self.client.call(module="first_mile", name="unbind_first_mile_tracking_number", payload=kwargs)

    def unbind_first_mile_tracking_number_all(self, **kwargs):
        """v2.first_mile.unbind_first_mile_tracking_number_all (POST)"""
        return self.client.call(module="first_mile", name="unbind_first_mile_tracking_number_all", payload=kwargs)
