from .base import BaseModule


class FollowPrize(BaseModule):
    def add_follow_prize(self, **kwargs):
        """v2.follow_prize.add_follow_prize (POST)"""
        return self.client.call(module="follow_prize", name="add_follow_prize", payload=kwargs)

    def delete_follow_prize(self, **kwargs):
        """v2.follow_prize.delete_follow_prize (POST)"""
        return self.client.call(module="follow_prize", name="delete_follow_prize", payload=kwargs)

    def end_follow_prize(self, **kwargs):
        """v2.follow_prize.end_follow_prize (POST)"""
        return self.client.call(module="follow_prize", name="end_follow_prize", payload=kwargs)

    def get_follow_prize_detail(self, **kwargs):
        """v2.follow_prize.get_follow_prize_detail (GET)"""
        return self.client.call(module="follow_prize", name="get_follow_prize_detail", payload=kwargs)

    def get_follow_prize_list(self, **kwargs):
        """v2.follow_prize.get_follow_prize_list (GET)"""
        return self.client.call(module="follow_prize", name="get_follow_prize_list", payload=kwargs)

    def update_follow_prize(self, **kwargs):
        """v2.follow_prize.update_follow_prize (POST)"""
        return self.client.call(module="follow_prize", name="update_follow_prize", payload=kwargs)
