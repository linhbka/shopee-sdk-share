from .base import BaseModule


class GlobalProduct(BaseModule):
    def add_global_item(self, **kwargs):
        """v2.global_product.add_global_item (POST)"""
        return self.client.call(module="global_product", name="add_global_item", payload=kwargs)

    def add_global_model(self, **kwargs):
        """v2.global_product.add_global_model (POST)"""
        return self.client.call(module="global_product", name="add_global_model", payload=kwargs)

    def category_recommend(self, **kwargs):
        """v2.global_product.category_recommend (GET)"""
        return self.client.call(module="global_product", name="category_recommend", payload=kwargs)

    def create_publish_task(self, **kwargs):
        """v2.global_product.create_publish_task (POST)"""
        return self.client.call(module="global_product", name="create_publish_task", payload=kwargs)

    def delete_global_item(self, **kwargs):
        """v2.global_product.delete_global_item (POST)"""
        return self.client.call(module="global_product", name="delete_global_item", payload=kwargs)

    def delete_global_model(self, **kwargs):
        """v2.global_product.delete_global_model (POST)"""
        return self.client.call(module="global_product", name="delete_global_model", payload=kwargs)

    def get_attribute_tree(self, **kwargs):
        """v2.global_product.get_attribute_tree (GET)"""
        return self.client.call(module="global_product", name="get_attribute_tree", payload=kwargs)

    def get_brand_list(self, **kwargs):
        """v2.global_product.get_brand_list (GET)"""
        return self.client.call(module="global_product", name="get_brand_list", payload=kwargs)

    def get_category(self, **kwargs):
        """v2.global_product.get_category (GET)"""
        return self.client.call(module="global_product", name="get_category", payload=kwargs)

    def get_global_item_id(self, **kwargs):
        """v2.global_product.get_global_item_id (GET)"""
        return self.client.call(module="global_product", name="get_global_item_id", payload=kwargs)

    def get_global_item_info(self, **kwargs):
        """v2.global_product.get_global_item_info (GET)"""
        return self.client.call(module="global_product", name="get_global_item_info", payload=kwargs)

    def get_global_item_limit(self, **kwargs):
        """v2.global_product.get_global_item_limit (GET)"""
        return self.client.call(module="global_product", name="get_global_item_limit", payload=kwargs)

    def get_global_item_list(self, **kwargs):
        """v2.global_product.get_global_item_list (GET)"""
        return self.client.call(module="global_product", name="get_global_item_list", payload=kwargs)

    def get_global_model_list(self, **kwargs):
        """v2.global_product.get_global_model_list (GET)"""
        return self.client.call(module="global_product", name="get_global_model_list", payload=kwargs)

    def get_local_adjustment_rate(self, **kwargs):
        """v2.global_product.get_local_adjustment_rate (GET)"""
        return self.client.call(module="global_product", name="get_local_adjustment_rate", payload=kwargs)

    def get_publish_task_result(self, **kwargs):
        """v2.global_product.get_publish_task_result (GET)"""
        return self.client.call(module="global_product", name="get_publish_task_result", payload=kwargs)

    def get_publishable_shop(self, **kwargs):
        """v2.global_product.get_publishable_shop (GET)"""
        return self.client.call(module="global_product", name="get_publishable_shop", payload=kwargs)

    def get_published_list(self, **kwargs):
        """v2.global_product.get_published_list (GET)"""
        return self.client.call(module="global_product", name="get_published_list", payload=kwargs)

    def get_recommend_attribute(self, **kwargs):
        """v2.global_product.get_recommend_attribute (GET)"""
        return self.client.call(module="global_product", name="get_recommend_attribute", payload=kwargs)

    def get_shop_publishable_status(self, **kwargs):
        """v2.global_product.get_shop_publishable_status (GET)"""
        return self.client.call(module="global_product", name="get_shop_publishable_status", payload=kwargs)

    def get_size_chart_detail(self, **kwargs):
        """v2.global_product.get_size_chart_detail (GET)"""
        return self.client.call(module="global_product", name="get_size_chart_detail", payload=kwargs)

    def get_size_chart_list(self, **kwargs):
        """v2.global_product.get_size_chart_list (GET)"""
        return self.client.call(module="global_product", name="get_size_chart_list", payload=kwargs)

    def get_variations(self, **kwargs):
        """v2.global_product.get_variations (GET)"""
        return self.client.call(module="global_product", name="get_variations", payload=kwargs)

    def init_tier_variation(self, **kwargs):
        """v2.global_product.init_tier_variation (POST)"""
        return self.client.call(module="global_product", name="init_tier_variation", payload=kwargs)

    def search_global_attribute_value_list(self, **kwargs):
        """v2.global_product.search_global_attribute_value_list (POST)"""
        return self.client.call(module="global_product", name="search_global_attribute_value_list", payload=kwargs)

    def set_sync_field(self, **kwargs):
        """v2.global_product.set_sync_field (POST)"""
        return self.client.call(module="global_product", name="set_sync_field", payload=kwargs)

    def support_size_chart(self, **kwargs):
        """v2.global_product.support_size_chart (GET)"""
        return self.client.call(module="global_product", name="support_size_chart", payload=kwargs)

    def update_global_item(self, **kwargs):
        """v2.global_product.update_global_item (POST)"""
        return self.client.call(module="global_product", name="update_global_item", payload=kwargs)

    def update_global_model(self, **kwargs):
        """v2.global_product.update_global_model (POST)"""
        return self.client.call(module="global_product", name="update_global_model", payload=kwargs)

    def update_local_adjustment_rate(self, **kwargs):
        """v2.global_product.update_local_adjustment_rate (POST)"""
        return self.client.call(module="global_product", name="update_local_adjustment_rate", payload=kwargs)

    def update_price(self, **kwargs):
        """v2.global_product.update_price (POST)"""
        return self.client.call(module="global_product", name="update_price", payload=kwargs)

    def update_size_chart(self, **kwargs):
        """v2.global_product.update_size_chart (POST)"""
        return self.client.call(module="global_product", name="update_size_chart", payload=kwargs)

    def update_stock(self, **kwargs):
        """v2.global_product.update_stock (POST)"""
        return self.client.call(module="global_product", name="update_stock", payload=kwargs)

    def update_tier_variation(self, **kwargs):
        """v2.global_product.update_tier_variation (POST)"""
        return self.client.call(module="global_product", name="update_tier_variation", payload=kwargs)
