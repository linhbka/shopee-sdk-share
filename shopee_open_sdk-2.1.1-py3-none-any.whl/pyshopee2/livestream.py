from .base import BaseModule


class Livestream(BaseModule):
    def add_item_list(self, **kwargs):
        """v2.livestream.add_item_list (POST)"""
        return self.client.call(module="livestream", name="add_item_list", payload=kwargs)

    def apply_item_set(self, **kwargs):
        """v2.livestream.apply_item_set (POST)"""
        return self.client.call(module="livestream", name="apply_item_set", payload=kwargs)

    def ban_user_comment(self, **kwargs):
        """v2.livestream.ban_user_comment (POST)"""
        return self.client.call(module="livestream", name="ban_user_comment", payload=kwargs)

    def create_session(self, **kwargs):
        """v2.livestream.create_session (POST)"""
        return self.client.call(module="livestream", name="create_session", payload=kwargs)

    def delete_item_list(self, **kwargs):
        """v2.livestream.delete_item_list (POST)"""
        return self.client.call(module="livestream", name="delete_item_list", payload=kwargs)

    def delete_show_item(self, **kwargs):
        """v2.livestream.delete_show_item (POST)"""
        return self.client.call(module="livestream", name="delete_show_item", payload=kwargs)

    def end_session(self, **kwargs):
        """v2.livestream.end_session (POST)"""
        return self.client.call(module="livestream", name="end_session", payload=kwargs)

    def get_item_count(self, **kwargs):
        """v2.livestream.get_item_count (GET)"""
        return self.client.call(module="livestream", name="get_item_count", payload=kwargs)

    def get_item_list(self, **kwargs):
        """v2.livestream.get_item_list (GET)"""
        return self.client.call(module="livestream", name="get_item_list", payload=kwargs)

    def get_item_set_item_list(self, **kwargs):
        """v2.livestream.get_item_set_item_list (GET)"""
        return self.client.call(module="livestream", name="get_item_set_item_list", payload=kwargs)

    def get_item_set_list(self, **kwargs):
        """v2.livestream.get_item_set_list (GET)"""
        return self.client.call(module="livestream", name="get_item_set_list", payload=kwargs)

    def get_latest_comment_list(self, **kwargs):
        """v2.livestream.get_latest_comment_list (GET)"""
        return self.client.call(module="livestream", name="get_latest_comment_list", payload=kwargs)

    def get_like_item_list(self, **kwargs):
        """v2.livestream.get_like_item_list (GET)"""
        return self.client.call(module="livestream", name="get_like_item_list", payload=kwargs)

    def get_recent_item_list(self, **kwargs):
        """v2.livestream.get_recent_item_list (GET)"""
        return self.client.call(module="livestream", name="get_recent_item_list", payload=kwargs)

    def get_session_detail(self, **kwargs):
        """v2.livestream.get_session_detail (GET)"""
        return self.client.call(module="livestream", name="get_session_detail", payload=kwargs)

    def get_session_item_metric(self, **kwargs):
        """v2.livestream.get_session_item_metric (GET)"""
        return self.client.call(module="livestream", name="get_session_item_metric", payload=kwargs)

    def get_session_metric(self, **kwargs):
        """v2.livestream.get_session_metric (GET)"""
        return self.client.call(module="livestream", name="get_session_metric", payload=kwargs)

    def get_show_item(self, **kwargs):
        """v2.livestream.get_show_item (GET)"""
        return self.client.call(module="livestream", name="get_show_item", payload=kwargs)

    def post_comment(self, **kwargs):
        """v2.livestream.post_comment (POST)"""
        return self.client.call(module="livestream", name="post_comment", payload=kwargs)

    def start_session(self, **kwargs):
        """v2.livestream.start_session (POST)"""
        return self.client.call(module="livestream", name="start_session", payload=kwargs)

    def unban_user_comment(self, **kwargs):
        """v2.livestream.unban_user_comment (POST)"""
        return self.client.call(module="livestream", name="unban_user_comment", payload=kwargs)

    def update_item_list(self, **kwargs):
        """v2.livestream.update_item_list (POST)"""
        return self.client.call(module="livestream", name="update_item_list", payload=kwargs)

    def update_session(self, **kwargs):
        """v2.livestream.update_session (POST)"""
        return self.client.call(module="livestream", name="update_session", payload=kwargs)

    def update_show_item(self, **kwargs):
        """v2.livestream.update_show_item (POST)"""
        return self.client.call(module="livestream", name="update_show_item", payload=kwargs)

    def upload_image(self, **kwargs):
        """v2.livestream.upload_image (POST)"""
        return self.client.call(module="livestream", name="upload_image", payload=kwargs)
