from .base import BaseModule


class Logistics(BaseModule):
    def batch_ship_order(self, **kwargs):
        """v2.logistics.batch_ship_order (POST)"""
        return self.client.call(module="logistics", name="batch_ship_order", payload=kwargs)

    def batch_update_tpf_warehouse_tracking_status(self, **kwargs):
        """v2.logistics.batch_update_tpf_warehouse_tracking_status (POST)"""
        return self.client.call(module="logistics", name="batch_update_tpf_warehouse_tracking_status", payload=kwargs)

    def check_polygon_update_status(self, **kwargs):
        """v2.logistics.check_polygon_update_status (POST)"""
        return self.client.call(module="logistics", name="check_polygon_update_status", payload=kwargs)

    def create_booking_shipping_document(self, **kwargs):
        """v2.logistics.create_booking_shipping_document (POST)"""
        return self.client.call(module="logistics", name="create_booking_shipping_document", payload=kwargs)

    def create_shipping_document(self, **kwargs):
        """v2.logistics.create_shipping_document (POST)"""
        return self.client.call(module="logistics", name="create_shipping_document", payload=kwargs)

    def create_shipping_document_job(self, **kwargs):
        """v2.logistics.create_shipping_document_job (POST)"""
        return self.client.call(module="logistics", name="create_shipping_document_job", payload=kwargs)

    def delete_address(self, **kwargs):
        """v2.logistics.delete_address (POST)"""
        return self.client.call(module="logistics", name="delete_address", payload=kwargs)

    def delete_special_operating_hour(self, **kwargs):
        """v2.logistics.delete_special_operating_hour (POST)"""
        return self.client.call(module="logistics", name="delete_special_operating_hour", payload=kwargs)

    def download_booking_shipping_document(self, **kwargs):
        """v2.logistics.download_booking_shipping_document (POST)"""
        return self.client.call(module="logistics", name="download_booking_shipping_document", payload=kwargs)

    def download_shipping_document(self, **kwargs):
        """v2.logistics.download_shipping_document (POST)"""
        return self.client.call(module="logistics", name="download_shipping_document", payload=kwargs)

    def download_shipping_document_job(self, **kwargs):
        """v2.logistics.download_shipping_document_job (POST)"""
        return self.client.call(module="logistics", name="download_shipping_document_job", payload=kwargs)

    def download_to_label(self, **kwargs):
        """v2.logistics.download_to_label (POST)"""
        return self.client.call(module="logistics", name="download_to_label", payload=kwargs)

    def get_address_list(self, **kwargs):
        """v2.logistics.get_address_list (GET)"""
        return self.client.call(module="logistics", name="get_address_list", payload=kwargs)

    def get_booking_shipping_document_data_info(self, **kwargs):
        """v2.logistics.get_booking_shipping_document_data_info (POST)"""
        return self.client.call(module="logistics", name="get_booking_shipping_document_data_info", payload=kwargs)

    def get_booking_shipping_document_parameter(self, **kwargs):
        """v2.logistics.get_booking_shipping_document_parameter (POST)"""
        return self.client.call(module="logistics", name="get_booking_shipping_document_parameter", payload=kwargs)

    def get_booking_shipping_document_result(self, **kwargs):
        """v2.logistics.get_booking_shipping_document_result (POST)"""
        return self.client.call(module="logistics", name="get_booking_shipping_document_result", payload=kwargs)

    def get_booking_shipping_parameter(self, **kwargs):
        """v2.logistics.get_booking_shipping_parameter (GET)"""
        return self.client.call(module="logistics", name="get_booking_shipping_parameter", payload=kwargs)

    def get_booking_tracking_info(self, **kwargs):
        """v2.logistics.get_booking_tracking_info (GET)"""
        return self.client.call(module="logistics", name="get_booking_tracking_info", payload=kwargs)

    def get_booking_tracking_number(self, **kwargs):
        """v2.logistics.get_booking_tracking_number (GET)"""
        return self.client.call(module="logistics", name="get_booking_tracking_number", payload=kwargs)

    def get_channel_list(self, **kwargs):
        """v2.logistics.get_channel_list (GET)"""
        return self.client.call(module="logistics", name="get_channel_list", payload=kwargs)

    def get_mart_packaging_info(self, **kwargs):
        """v2.logistics.get_mart_packaging_info (GET)"""
        return self.client.call(module="logistics", name="get_mart_packaging_info", payload=kwargs)

    def get_mass_shipping_parameter(self, **kwargs):
        """v2.logistics.get_mass_shipping_parameter (POST)"""
        return self.client.call(module="logistics", name="get_mass_shipping_parameter", payload=kwargs)

    def get_mass_tracking_number(self, **kwargs):
        """v2.logistics.get_mass_tracking_number (POST)"""
        return self.client.call(module="logistics", name="get_mass_tracking_number", payload=kwargs)

    def get_operating_hour_restrictions(self, **kwargs):
        """v2.logistics.get_operating_hour_restrictions (GET)"""
        return self.client.call(module="logistics", name="get_operating_hour_restrictions", payload=kwargs)

    def get_operating_hours(self, **kwargs):
        """v2.logistics.get_operating_hours (GET)"""
        return self.client.call(module="logistics", name="get_operating_hours", payload=kwargs)

    def get_shipping_document_data_info(self, **kwargs):
        """v2.logistics.get_shipping_document_data_info (POST)"""
        return self.client.call(module="logistics", name="get_shipping_document_data_info", payload=kwargs)

    def get_shipping_document_job_status(self, **kwargs):
        """v2.logistics.get_shipping_document_job_status (POST)"""
        return self.client.call(module="logistics", name="get_shipping_document_job_status", payload=kwargs)

    def get_shipping_document_parameter(self, **kwargs):
        """v2.logistics.get_shipping_document_parameter (POST)"""
        return self.client.call(module="logistics", name="get_shipping_document_parameter", payload=kwargs)

    def get_shipping_document_result(self, **kwargs):
        """v2.logistics.get_shipping_document_result (POST)"""
        return self.client.call(module="logistics", name="get_shipping_document_result", payload=kwargs)

    def get_shipping_parameter(self, **kwargs):
        """v2.logistics.get_shipping_parameter (GET)"""
        return self.client.call(module="logistics", name="get_shipping_parameter", payload=kwargs)

    def get_tracking_info(self, **kwargs):
        """v2.logistics.get_tracking_info (GET)"""
        return self.client.call(module="logistics", name="get_tracking_info", payload=kwargs)

    def get_tracking_number(self, **kwargs):
        """v2.logistics.get_tracking_number (GET)"""
        return self.client.call(module="logistics", name="get_tracking_number", payload=kwargs)

    def mass_ship_order(self, **kwargs):
        """v2.logistics.mass_ship_order (POST)"""
        return self.client.call(module="logistics", name="mass_ship_order", payload=kwargs)

    def set_address_config(self, **kwargs):
        """v2.logistics.set_address_config (POST)"""
        return self.client.call(module="logistics", name="set_address_config", payload=kwargs)

    def set_mart_packaging_info(self, **kwargs):
        """v2.logistics.set_mart_packaging_info (POST)"""
        return self.client.call(module="logistics", name="set_mart_packaging_info", payload=kwargs)

    def ship_booking(self, **kwargs):
        """v2.logistics.ship_booking (POST)"""
        return self.client.call(module="logistics", name="ship_booking", payload=kwargs)

    def ship_order(self, **kwargs):
        """v2.logistics.ship_order (POST)"""
        return self.client.call(module="logistics", name="ship_order", payload=kwargs)

    def update_address(self, **kwargs):
        """v2.logistics.update_address (POST)"""
        return self.client.call(module="logistics", name="update_address", payload=kwargs)

    def update_channel(self, **kwargs):
        """v2.logistics.update_channel (POST)"""
        return self.client.call(module="logistics", name="update_channel", payload=kwargs)

    def update_operating_hours(self, **kwargs):
        """v2.logistics.update_operating_hours (POST)"""
        return self.client.call(module="logistics", name="update_operating_hours", payload=kwargs)

    def update_self_collection_order_logistics(self, **kwargs):
        """v2.logistics.update_self_collection_order_logistics (POST)"""
        return self.client.call(module="logistics", name="update_self_collection_order_logistics", payload=kwargs)

    def update_shipping_order(self, **kwargs):
        """v2.logistics.update_shipping_order (POST)"""
        return self.client.call(module="logistics", name="update_shipping_order", payload=kwargs)

    def update_tracking_status(self, **kwargs):
        """v2.logistics.update_tracking_status (POST)"""
        return self.client.call(module="logistics", name="update_tracking_status", payload=kwargs)

    def upload_serviceable_polygon(self, **kwargs):
        """v2.logistics.upload_serviceable_polygon (POST)"""
        return self.client.call(module="logistics", name="upload_serviceable_polygon", payload=kwargs)
