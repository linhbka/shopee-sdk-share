from .base import BaseModule


class Media(BaseModule):
    def cancel_video_upload(self, **kwargs):
        """v2.media.cancel_video_upload (POST)"""
        return self.client.call(module="media", name="cancel_video_upload", payload=kwargs)

    def complete_video_upload(self, **kwargs):
        """v2.media.complete_video_upload (POST)"""
        return self.client.call(module="media", name="complete_video_upload", payload=kwargs)

    def get_video_upload_result(self, **kwargs):
        """v2.media.get_video_upload_result (GET)"""
        return self.client.call(module="media", name="get_video_upload_result", payload=kwargs)

    def init_video_upload(self, **kwargs):
        """v2.media.init_video_upload (POST)"""
        return self.client.call(module="media", name="init_video_upload", payload=kwargs)

    def upload_image(self, **kwargs):
        """v2.media.upload_image (POST)"""
        return self.client.call(module="media", name="upload_image", payload=kwargs)

    def upload_video_part(self, **kwargs):
        """v2.media.upload_video_part (POST)"""
        return self.client.call(module="media", name="upload_video_part", payload=kwargs)
