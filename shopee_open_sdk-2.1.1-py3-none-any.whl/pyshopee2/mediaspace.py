from .base import BaseModule


class MediaSpace(BaseModule):
    def cancel_video_upload(self, **kwargs):
        """v2.media_space.cancel_video_upload (POST)"""
        return self.client.call(module="media_space", name="cancel_video_upload", payload=kwargs)

    def complete_video_upload(self, **kwargs):
        """v2.media_space.complete_video_upload (POST)"""
        return self.client.call(module="media_space", name="complete_video_upload", payload=kwargs)

    def get_video_upload_result(self, **kwargs):
        """v2.media_space.get_video_upload_result (GET)"""
        return self.client.call(module="media_space", name="get_video_upload_result", payload=kwargs)

    def init_video_upload(self, **kwargs):
        """v2.media_space.init_video_upload (POST)"""
        return self.client.call(module="media_space", name="init_video_upload", payload=kwargs)

    def upload_image(self, **kwargs):
        """v2.media_space.upload_image (POST)"""
        return self.client.call(module="media_space", name="upload_image", payload=kwargs)

    def upload_video_part(self, **kwargs):
        """v2.media_space.upload_video_part (POST)"""
        return self.client.call(module="media_space", name="upload_video_part", payload=kwargs)
