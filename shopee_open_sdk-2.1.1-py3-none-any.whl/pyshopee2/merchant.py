from .base import BaseModule


class Merchant(BaseModule):
    def get_merchant_info(self, **kwargs):
        """v2.merchant.get_merchant_info (GET)"""
        return self.client.call(module="merchant", name="get_merchant_info", payload=kwargs)

    def get_merchant_prepaid_account_list(self, **kwargs):
        """v2.merchant.get_merchant_prepaid_account_list (GET)"""
        return self.client.call(module="merchant", name="get_merchant_prepaid_account_list", payload=kwargs)

    def get_merchant_warehouse_list(self, **kwargs):
        """v2.merchant.get_merchant_warehouse_list (POST)"""
        return self.client.call(module="merchant", name="get_merchant_warehouse_list", payload=kwargs)

    def get_merchant_warehouse_location_list(self, **kwargs):
        """v2.merchant.get_merchant_warehouse_location_list (GET)"""
        return self.client.call(module="merchant", name="get_merchant_warehouse_location_list", payload=kwargs)

    def get_shop_list_by_merchant(self, **kwargs):
        """v2.merchant.get_shop_list_by_merchant (GET)"""
        return self.client.call(module="merchant", name="get_shop_list_by_merchant", payload=kwargs)

    def get_warehouse_eligible_shop_list(self, **kwargs):
        """v2.merchant.get_warehouse_eligible_shop_list (POST)"""
        return self.client.call(module="merchant", name="get_warehouse_eligible_shop_list", payload=kwargs)
