from .base import BaseModule


class Order(BaseModule):
    def cancel_order(self, **kwargs):
        """v2.order.cancel_order (POST)"""
        return self.client.call(module="order", name="cancel_order", payload=kwargs)

    def download_fbs_invoices(self, **kwargs):
        """v2.order.download_fbs_invoices (POST)"""
        return self.client.call(module="order", name="download_fbs_invoices", payload=kwargs)

    def download_invoice_doc(self, **kwargs):
        """v2.order.download_invoice_doc (GET)"""
        return self.client.call(module="order", name="download_invoice_doc", payload=kwargs)

    def generate_fbs_invoices(self, **kwargs):
        """v2.order.generate_fbs_invoices (POST)"""
        return self.client.call(module="order", name="generate_fbs_invoices", payload=kwargs)

    def get_booking_detail(self, **kwargs):
        """v2.order.get_booking_detail (GET)"""
        return self.client.call(module="order", name="get_booking_detail", payload=kwargs)

    def get_booking_list(self, **kwargs):
        """v2.order.get_booking_list (GET)"""
        return self.client.call(module="order", name="get_booking_list", payload=kwargs)

    def get_buyer_invoice_info(self, **kwargs):
        """v2.order.get_buyer_invoice_info (POST)"""
        return self.client.call(module="order", name="get_buyer_invoice_info", payload=kwargs)

    def get_fbs_invoices_result(self, **kwargs):
        """v2.order.get_fbs_invoices_result (POST)"""
        return self.client.call(module="order", name="get_fbs_invoices_result", payload=kwargs)

    def get_order_detail(self, **kwargs):
        """v2.order.get_order_detail (GET)"""
        return self.client.call(module="order", name="get_order_detail", payload=kwargs)

    def get_order_list(self, **kwargs):
        """v2.order.get_order_list (GET)"""
        return self.client.call(module="order", name="get_order_list", payload=kwargs)

    def get_package_detail(self, **kwargs):
        """v2.order.get_package_detail (GET)"""
        return self.client.call(module="order", name="get_package_detail", payload=kwargs)

    def get_pending_buyer_invoice_order_list(self, **kwargs):
        """v2.order.get_pending_buyer_invoice_order_list (GET)"""
        return self.client.call(module="order", name="get_pending_buyer_invoice_order_list", payload=kwargs)

    def get_shipment_list(self, **kwargs):
        """v2.order.get_shipment_list (GET)"""
        return self.client.call(module="order", name="get_shipment_list", payload=kwargs)

    def get_warehouse_filter_config(self, **kwargs):
        """v2.order.get_warehouse_filter_config (GET)"""
        return self.client.call(module="order", name="get_warehouse_filter_config", payload=kwargs)

    def handle_buyer_cancellation(self, **kwargs):
        """v2.order.handle_buyer_cancellation (POST)"""
        return self.client.call(module="order", name="handle_buyer_cancellation", payload=kwargs)

    def handle_prescription_check(self, **kwargs):
        """v2.order.handle_prescription_check (POST)"""
        return self.client.call(module="order", name="handle_prescription_check", payload=kwargs)

    def search_package_list(self, **kwargs):
        """v2.order.search_package_list (POST)"""
        return self.client.call(module="order", name="search_package_list", payload=kwargs)

    def set_note(self, **kwargs):
        """v2.order.set_note (POST)"""
        return self.client.call(module="order", name="set_note", payload=kwargs)

    def split_order(self, **kwargs):
        """v2.order.split_order (POST)"""
        return self.client.call(module="order", name="split_order", payload=kwargs)

    def unsplit_order(self, **kwargs):
        """v2.order.unsplit_order (POST)"""
        return self.client.call(module="order", name="unsplit_order", payload=kwargs)

    def upload_invoice_doc(self, **kwargs):
        """v2.order.upload_invoice_doc (POST)"""
        return self.client.call(module="order", name="upload_invoice_doc", payload=kwargs)
