from .base import BaseModule


class Payment(BaseModule):
    def generate_income_report(self, **kwargs):
        """v2.payment.generate_income_report (GET)"""
        return self.client.call(module="payment", name="generate_income_report", payload=kwargs)

    def generate_income_statement(self, **kwargs):
        """v2.payment.generate_income_statement (GET)"""
        return self.client.call(module="payment", name="generate_income_statement", payload=kwargs)

    def get_billing_transaction_info(self, **kwargs):
        """v2.payment.get_billing_transaction_info (POST)"""
        return self.client.call(module="payment", name="get_billing_transaction_info", payload=kwargs)

    def get_escrow_detail(self, **kwargs):
        """v2.payment.get_escrow_detail (GET)"""
        return self.client.call(module="payment", name="get_escrow_detail", payload=kwargs)

    def get_escrow_detail_batch(self, **kwargs):
        """v2.payment.get_escrow_detail_batch (POST)"""
        return self.client.call(module="payment", name="get_escrow_detail_batch", payload=kwargs)

    def get_escrow_list(self, **kwargs):
        """v2.payment.get_escrow_list (GET)"""
        return self.client.call(module="payment", name="get_escrow_list", payload=kwargs)

    def get_income_detail(self, **kwargs):
        """v2.payment.get_income_detail (GET)"""
        return self.client.call(module="payment", name="get_income_detail", payload=kwargs)

    def get_income_overview(self, **kwargs):
        """v2.payment.get_income_overview (GET)"""
        return self.client.call(module="payment", name="get_income_overview", payload=kwargs)

    def get_income_report(self, **kwargs):
        """v2.payment.get_income_report (GET)"""
        return self.client.call(module="payment", name="get_income_report", payload=kwargs)

    def get_income_statement(self, **kwargs):
        """v2.payment.get_income_statement (GET)"""
        return self.client.call(module="payment", name="get_income_statement", payload=kwargs)

    def get_item_installment_status(self, **kwargs):
        """v2.payment.get_item_installment_status (POST)"""
        return self.client.call(module="payment", name="get_item_installment_status", payload=kwargs)

    def get_payment_method_list(self, **kwargs):
        """v2.payment.get_payment_method_list (GET)"""
        return self.client.call(module="payment", name="get_payment_method_list", payload=kwargs)

    def get_payout_detail(self, **kwargs):
        """v2.payment.get_payout_detail (GET)"""
        return self.client.call(module="payment", name="get_payout_detail", payload=kwargs)

    def get_payout_info(self, **kwargs):
        """v2.payment.get_payout_info (GET)"""
        return self.client.call(module="payment", name="get_payout_info", payload=kwargs)

    def get_shop_installment_status(self, **kwargs):
        """v2.payment.get_shop_installment_status (GET)"""
        return self.client.call(module="payment", name="get_shop_installment_status", payload=kwargs)

    def get_wallet_transaction_list(self, **kwargs):
        """v2.payment.get_wallet_transaction_list (GET)"""
        return self.client.call(module="payment", name="get_wallet_transaction_list", payload=kwargs)

    def set_item_installment_status(self, **kwargs):
        """v2.payment.set_item_installment_status (POST)"""
        return self.client.call(module="payment", name="set_item_installment_status", payload=kwargs)

    def set_shop_installment_status(self, **kwargs):
        """v2.payment.set_shop_installment_status (POST)"""
        return self.client.call(module="payment", name="set_shop_installment_status", payload=kwargs)
