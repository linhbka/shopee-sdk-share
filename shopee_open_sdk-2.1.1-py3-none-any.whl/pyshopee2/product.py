from .base import BaseModule


class Product(BaseModule):
    def add_item(self, **kwargs):
        """v2.product.add_item (POST)"""
        return self.client.call(module="product", name="add_item", payload=kwargs)

    def add_kit_item(self, **kwargs):
        """v2.product.add_kit_item (POST)"""
        return self.client.call(module="product", name="add_kit_item", payload=kwargs)

    def add_model(self, **kwargs):
        """v2.product.add_model (POST)"""
        return self.client.call(module="product", name="add_model", payload=kwargs)

    def add_ssp_item(self, **kwargs):
        """v2.product.add_ssp_item (POST)"""
        return self.client.call(module="product", name="add_ssp_item", payload=kwargs)

    def boost_item(self, **kwargs):
        """v2.product.boost_item (POST)"""
        return self.client.call(module="product", name="boost_item", payload=kwargs)

    def category_recommend(self, **kwargs):
        """v2.product.category_recommend (GET)"""
        return self.client.call(module="product", name="category_recommend", payload=kwargs)

    def delete_item(self, **kwargs):
        """v2.product.delete_item (POST)"""
        return self.client.call(module="product", name="delete_item", payload=kwargs)

    def delete_model(self, **kwargs):
        """v2.product.delete_model (POST)"""
        return self.client.call(module="product", name="delete_model", payload=kwargs)

    def generate_kit_image(self, **kwargs):
        """v2.product.generate_kit_image (POST)"""
        return self.client.call(module="product", name="generate_kit_image", payload=kwargs)

    def get_aitem_by_pitem_id(self, **kwargs):
        """v2.product.get_aitem_by_pitem_id (GET)"""
        return self.client.call(module="product", name="get_aitem_by_pitem_id", payload=kwargs)

    def get_all_vehicle_list(self, **kwargs):
        """v2.product.get_all_vehicle_list (GET)"""
        return self.client.call(module="product", name="get_all_vehicle_list", payload=kwargs)

    def get_attribute_tree(self, **kwargs):
        """v2.product.get_attribute_tree (GET)"""
        return self.client.call(module="product", name="get_attribute_tree", payload=kwargs)

    def get_boosted_list(self, **kwargs):
        """v2.product.get_boosted_list (GET)"""
        return self.client.call(module="product", name="get_boosted_list", payload=kwargs)

    def get_brand_list(self, **kwargs):
        """v2.product.get_brand_list (GET)"""
        return self.client.call(module="product", name="get_brand_list", payload=kwargs)

    def get_category(self, **kwargs):
        """v2.product.get_category (GET)"""
        return self.client.call(module="product", name="get_category", payload=kwargs)

    def get_comment(self, **kwargs):
        """v2.product.get_comment (GET)"""
        return self.client.call(module="product", name="get_comment", payload=kwargs)

    def get_direct_item_list(self, **kwargs):
        """v2.product.get_direct_item_list (GET)"""
        return self.client.call(module="product", name="get_direct_item_list", payload=kwargs)

    def get_direct_shop_recommended_price(self, **kwargs):
        """v2.product.get_direct_shop_recommended_price (GET)"""
        return self.client.call(module="product", name="get_direct_shop_recommended_price", payload=kwargs)

    def get_item_base_info(self, **kwargs):
        """v2.product.get_item_base_info (GET)"""
        return self.client.call(module="product", name="get_item_base_info", payload=kwargs)

    def get_item_content_diagnosis_result(self, **kwargs):
        """v2.product.get_item_content_diagnosis_result (POST)"""
        return self.client.call(module="product", name="get_item_content_diagnosis_result", payload=kwargs)

    def get_item_extra_info(self, **kwargs):
        """v2.product.get_item_extra_info (GET)"""
        return self.client.call(module="product", name="get_item_extra_info", payload=kwargs)

    def get_item_limit(self, **kwargs):
        """v2.product.get_item_limit (GET)"""
        return self.client.call(module="product", name="get_item_limit", payload=kwargs)

    def get_item_list(self, **kwargs):
        """v2.product.get_item_list (GET)"""
        return self.client.call(module="product", name="get_item_list", payload=kwargs)

    def get_item_list_by_content_diagnosis(self, **kwargs):
        """v2.product.get_item_list_by_content_diagnosis (POST)"""
        return self.client.call(module="product", name="get_item_list_by_content_diagnosis", payload=kwargs)

    def get_item_promotion(self, **kwargs):
        """v2.product.get_item_promotion (GET)"""
        return self.client.call(module="product", name="get_item_promotion", payload=kwargs)

    def get_item_violation_info(self, **kwargs):
        """v2.product.get_item_violation_info (GET)"""
        return self.client.call(module="product", name="get_item_violation_info", payload=kwargs)

    def get_kit_item_info(self, **kwargs):
        """v2.product.get_kit_item_info (GET)"""
        return self.client.call(module="product", name="get_kit_item_info", payload=kwargs)

    def get_kit_item_limit(self, **kwargs):
        """v2.product.get_kit_item_limit (GET)"""
        return self.client.call(module="product", name="get_kit_item_limit", payload=kwargs)

    def get_main_item_list(self, **kwargs):
        """v2.product.get_main_item_list (GET)"""
        return self.client.call(module="product", name="get_main_item_list", payload=kwargs)

    def get_mart_item_mapping_by_id(self, **kwargs):
        """v2.product.get_mart_item_mapping_by_id (POST)"""
        return self.client.call(module="product", name="get_mart_item_mapping_by_id", payload=kwargs)

    def get_model_list(self, **kwargs):
        """v2.product.get_model_list (GET)"""
        return self.client.call(module="product", name="get_model_list", payload=kwargs)

    def get_product_certification_rule(self, **kwargs):
        """v2.product.get_product_certification_rule (POST)"""
        return self.client.call(module="product", name="get_product_certification_rule", payload=kwargs)

    def get_recommend_attribute(self, **kwargs):
        """v2.product.get_recommend_attribute (GET)"""
        return self.client.call(module="product", name="get_recommend_attribute", payload=kwargs)

    def get_size_chart_detail(self, **kwargs):
        """v2.product.get_size_chart_detail (GET)"""
        return self.client.call(module="product", name="get_size_chart_detail", payload=kwargs)

    def get_size_chart_list(self, **kwargs):
        """v2.product.get_size_chart_list (GET)"""
        return self.client.call(module="product", name="get_size_chart_list", payload=kwargs)

    def get_ssp_info(self, **kwargs):
        """v2.product.get_ssp_info (GET)"""
        return self.client.call(module="product", name="get_ssp_info", payload=kwargs)

    def get_ssp_list(self, **kwargs):
        """v2.product.get_ssp_list (GET)"""
        return self.client.call(module="product", name="get_ssp_list", payload=kwargs)

    def get_variations(self, **kwargs):
        """v2.product.get_variations (GET)"""
        return self.client.call(module="product", name="get_variations", payload=kwargs)

    def get_vehicle_list_by_compatibility_detail(self, **kwargs):
        """v2.product.get_vehicle_list_by_compatibility_detail (GET)"""
        return self.client.call(module="product", name="get_vehicle_list_by_compatibility_detail", payload=kwargs)

    def get_weight_recommendation(self, **kwargs):
        """v2.product.get_weight_recommendation (POST)"""
        return self.client.call(module="product", name="get_weight_recommendation", payload=kwargs)

    def init_tier_variation(self, **kwargs):
        """v2.product.init_tier_variation (POST)"""
        return self.client.call(module="product", name="init_tier_variation", payload=kwargs)

    def link_ssp(self, **kwargs):
        """v2.product.link_ssp (POST)"""
        return self.client.call(module="product", name="link_ssp", payload=kwargs)

    def publish_item_to_outlet_shop(self, **kwargs):
        """v2.product.publish_item_to_outlet_shop (POST)"""
        return self.client.call(module="product", name="publish_item_to_outlet_shop", payload=kwargs)

    def register_brand(self, **kwargs):
        """v2.product.register_brand (POST)"""
        return self.client.call(module="product", name="register_brand", payload=kwargs)

    def reply_comment(self, **kwargs):
        """v2.product.reply_comment (POST)"""
        return self.client.call(module="product", name="reply_comment", payload=kwargs)

    def search_attribute_value_list(self, **kwargs):
        """v2.product.search_attribute_value_list (POST)"""
        return self.client.call(module="product", name="search_attribute_value_list", payload=kwargs)

    def search_item(self, **kwargs):
        """v2.product.search_item (GET)"""
        return self.client.call(module="product", name="search_item", payload=kwargs)

    def search_unpackaged_model_list(self, **kwargs):
        """v2.product.search_unpackaged_model_list (POST)"""
        return self.client.call(module="product", name="search_unpackaged_model_list", payload=kwargs)

    def unlink_ssp(self, **kwargs):
        """v2.product.unlink_ssp (POST)"""
        return self.client.call(module="product", name="unlink_ssp", payload=kwargs)

    def unlist_item(self, **kwargs):
        """v2.product.unlist_item (POST)"""
        return self.client.call(module="product", name="unlist_item", payload=kwargs)

    def update_item(self, **kwargs):
        """v2.product.update_item (POST)"""
        return self.client.call(module="product", name="update_item", payload=kwargs)

    def update_kit_item(self, **kwargs):
        """v2.product.update_kit_item (POST)"""
        return self.client.call(module="product", name="update_kit_item", payload=kwargs)

    def update_model(self, **kwargs):
        """v2.product.update_model (POST)"""
        return self.client.call(module="product", name="update_model", payload=kwargs)

    def update_price(self, **kwargs):
        """v2.product.update_price (POST)"""
        return self.client.call(module="product", name="update_price", payload=kwargs)

    def update_sip_item_price(self, **kwargs):
        """v2.product.update_sip_item_price (POST)"""
        return self.client.call(module="product", name="update_sip_item_price", payload=kwargs)

    def update_stock(self, **kwargs):
        """v2.product.update_stock (POST)"""
        return self.client.call(module="product", name="update_stock", payload=kwargs)

    def update_tier_variation(self, **kwargs):
        """v2.product.update_tier_variation (POST)"""
        return self.client.call(module="product", name="update_tier_variation", payload=kwargs)
