from .base import BaseModule


class Public(BaseModule):
    def get_access_token(self, **kwargs):
        """v2.public.get_access_token (POST)"""
        return self.client.call(module="public", name="get_access_token", payload=kwargs)

    def get_merchants_by_partner(self, **kwargs):
        """v2.public.get_merchants_by_partner (GET)"""
        return self.client.call(module="public", name="get_merchants_by_partner", payload=kwargs)

    def get_shopee_ip_ranges(self, **kwargs):
        """v2.public.get_shopee_ip_ranges (GET)"""
        return self.client.call(module="public", name="get_shopee_ip_ranges", payload=kwargs)

    def get_shops_by_partner(self, **kwargs):
        """v2.public.get_shops_by_partner (GET)"""
        return self.client.call(module="public", name="get_shops_by_partner", payload=kwargs)

    def get_token_by_resend_code(self, **kwargs):
        """v2.public.get_token_by_resend_code (POST)"""
        return self.client.call(module="public", name="get_token_by_resend_code", payload=kwargs)

    def refresh_access_token(self, **kwargs):
        """v2.public.refresh_access_token (POST)"""
        return self.client.call(module="public", name="refresh_access_token", payload=kwargs)
