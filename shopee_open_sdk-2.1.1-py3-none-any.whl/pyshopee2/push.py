from .base import BaseModule


class Push(BaseModule):
    def confirm_consumed_lost_push_message(self, **kwargs):
        """v2.push.confirm_consumed_lost_push_message (POST)"""
        return self.client.call(module="push", name="confirm_consumed_lost_push_message", payload=kwargs)

    def get_app_push_config(self, **kwargs):
        """v2.push.get_app_push_config (GET)"""
        return self.client.call(module="push", name="get_app_push_config", payload=kwargs)

    def get_lost_push_message(self, **kwargs):
        """v2.push.get_lost_push_message (GET)"""
        return self.client.call(module="push", name="get_lost_push_message", payload=kwargs)

    def set_app_push_config(self, **kwargs):
        """v2.push.set_app_push_config (POST)"""
        return self.client.call(module="push", name="set_app_push_config", payload=kwargs)
