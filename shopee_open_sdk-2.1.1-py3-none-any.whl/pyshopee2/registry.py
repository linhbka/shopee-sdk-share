import json
from pathlib import Path

from .exceptions import EndpointNotFoundError


class EndpointRegistry:
    def __init__(self, mapping):
        self.mapping = mapping
        self._by_path = {value["path"]: value for value in mapping.values() if value.get("path")}
        self._by_module_function = {}
        self._by_function = {}
        self._module_alias = {}

        for value in mapping.values():
            raw_module = value.get("module")
            module = self._norm(raw_module)
            function = (value.get("function") or "").lower()
            if module and function:
                self._by_module_function[(module, function)] = value
                self._module_alias.setdefault(module, raw_module)
            if function:
                self._by_function.setdefault(function, []).append(value)

    @staticmethod
    def _norm(module_name):
        text = str(module_name or "").lower()
        return text.replace("_", "").replace("-", "").replace(" ", "")

    @classmethod
    def from_file(cls, file_path):
        file_path = Path(file_path)
        payload = json.loads(file_path.read_text(encoding="utf-8"))
        return cls(payload)

    def find(self, *, api_name=None, module=None, function=None, uri=None):
        if api_name and api_name in self.mapping:
            return self.mapping[api_name]

        if uri:
            clean = uri.strip().strip("/")
            if clean.startswith("api/v2/"):
                clean = clean[len("api/v2/") :]
            full_path = f"/api/v2/{clean}"
            if full_path in self._by_path:
                return self._by_path[full_path]
            if "/" in clean:
                guessed_module, guessed_function = clean.split("/", 1)
                guessed = self._by_module_function.get((self._norm(guessed_module), guessed_function))
                if guessed:
                    return guessed
                candidates = self._by_function.get(guessed_function, [])
                if len(candidates) == 1:
                    return candidates[0]

        if module and function:
            value = self._by_module_function.get((self._norm(module), function.lower()))
            if value:
                return value

        if function:
            candidates = self._by_function.get(function.lower(), [])
            if len(candidates) == 1:
                return candidates[0]

        raise EndpointNotFoundError(
            f"Cannot resolve endpoint. api_name={api_name}, module={module}, function={function}, uri={uri}"
        )

    def resolve_module(self, module_name):
        normalized = self._norm(module_name)
        return self._module_alias.get(normalized)

    def list_modules(self):
        return sorted(set(self._module_alias.values()))
