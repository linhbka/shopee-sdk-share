from .base import BaseModule


class Returns(BaseModule):
    def accept_offer(self, **kwargs):
        """v2.returns.accept_offer (POST)"""
        return self.client.call(module="returns", name="accept_offer", payload=kwargs)

    def cancel_dispute(self, **kwargs):
        """v2.returns.cancel_dispute (POST)"""
        return self.client.call(module="returns", name="cancel_dispute", payload=kwargs)

    def confirm(self, **kwargs):
        """v2.returns.confirm (POST)"""
        return self.client.call(module="returns", name="confirm", payload=kwargs)

    def convert_image(self, **kwargs):
        """v2.returns.convert_image (POST)"""
        return self.client.call(module="returns", name="convert_image", payload=kwargs)

    def dispute(self, **kwargs):
        """v2.returns.dispute (POST)"""
        return self.client.call(module="returns", name="dispute", payload=kwargs)

    def get_available_solutions(self, **kwargs):
        """v2.returns.get_available_solutions (GET)"""
        return self.client.call(module="returns", name="get_available_solutions", payload=kwargs)

    def get_return_detail(self, **kwargs):
        """v2.returns.get_return_detail (GET)"""
        return self.client.call(module="returns", name="get_return_detail", payload=kwargs)

    def get_return_dispute_reason(self, **kwargs):
        """v2.returns.get_return_dispute_reason (GET)"""
        return self.client.call(module="returns", name="get_return_dispute_reason", payload=kwargs)

    def get_return_list(self, **kwargs):
        """v2.returns.get_return_list (GET)"""
        return self.client.call(module="returns", name="get_return_list", payload=kwargs)

    def get_reverse_tracking_info(self, **kwargs):
        """v2.returns.get_reverse_tracking_info (GET)"""
        return self.client.call(module="returns", name="get_reverse_tracking_info", payload=kwargs)

    def get_shipping_carrier(self, **kwargs):
        """v2.returns.get_shipping_carrier (GET)"""
        return self.client.call(module="returns", name="get_shipping_carrier", payload=kwargs)

    def offer(self, **kwargs):
        """v2.returns.offer (POST)"""
        return self.client.call(module="returns", name="offer", payload=kwargs)

    def query_proof(self, **kwargs):
        """v2.returns.query_proof (GET)"""
        return self.client.call(module="returns", name="query_proof", payload=kwargs)

    def upload_proof(self, **kwargs):
        """v2.returns.upload_proof (POST)"""
        return self.client.call(module="returns", name="upload_proof", payload=kwargs)

    def upload_shipping_proof(self, **kwargs):
        """v2.returns.upload_shipping_proof (POST)"""
        return self.client.call(module="returns", name="upload_shipping_proof", payload=kwargs)
