from .base import BaseModule


class Sbs(BaseModule):
    def get_bound_whs_info(self, **kwargs):
        """v2.sbs.get_bound_whs_info (GET)"""
        return self.client.call(module="sbs", name="get_bound_whs_info", payload=kwargs)

    def get_current_inventory(self, **kwargs):
        """v2.sbs.get_current_inventory (GET)"""
        return self.client.call(module="sbs", name="get_current_inventory", payload=kwargs)

    def get_expiry_report(self, **kwargs):
        """v2.sbs.get_expiry_report (GET)"""
        return self.client.call(module="sbs", name="get_expiry_report", payload=kwargs)

    def get_stock_aging(self, **kwargs):
        """v2.sbs.get_stock_aging (GET)"""
        return self.client.call(module="sbs", name="get_stock_aging", payload=kwargs)

    def get_stock_movement(self, **kwargs):
        """v2.sbs.get_stock_movement (GET)"""
        return self.client.call(module="sbs", name="get_stock_movement", payload=kwargs)
