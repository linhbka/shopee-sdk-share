from .base import BaseModule


class Shop(BaseModule):
    def get_authorised_reseller_brand(self, **kwargs):
        """v2.shop.get_authorised_reseller_brand (GET)"""
        return self.client.call(module="shop", name="get_authorised_reseller_brand", payload=kwargs)

    def get_br_shop_onboarding_info(self, **kwargs):
        """v2.shop.get_br_shop_onboarding_info (GET)"""
        return self.client.call(module="shop", name="get_br_shop_onboarding_info", payload=kwargs)

    def get_profile(self, **kwargs):
        """v2.shop.get_profile (GET)"""
        return self.client.call(module="shop", name="get_profile", payload=kwargs)

    def get_shop_holiday_mode(self, **kwargs):
        """v2.shop.get_shop_holiday_mode (GET)"""
        return self.client.call(module="shop", name="get_shop_holiday_mode", payload=kwargs)

    def get_shop_info(self, **kwargs):
        """v2.shop.get_shop_info (GET)"""
        return self.client.call(module="shop", name="get_shop_info", payload=kwargs)

    def get_shop_notification(self, **kwargs):
        """v2.shop.get_shop_notification (GET)"""
        return self.client.call(module="shop", name="get_shop_notification", payload=kwargs)

    def get_warehouse_detail(self, **kwargs):
        """v2.shop.get_warehouse_detail (GET)"""
        return self.client.call(module="shop", name="get_warehouse_detail", payload=kwargs)

    def set_shop_holiday_mode(self, **kwargs):
        """v2.shop.set_shop_holiday_mode (POST)"""
        return self.client.call(module="shop", name="set_shop_holiday_mode", payload=kwargs)

    def update_profile(self, **kwargs):
        """v2.shop.update_profile (POST)"""
        return self.client.call(module="shop", name="update_profile", payload=kwargs)
