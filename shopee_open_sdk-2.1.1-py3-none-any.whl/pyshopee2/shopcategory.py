from .base import BaseModule


class ShopCategory(BaseModule):
    def add_item_list(self, **kwargs):
        """v2.shop_category.add_item_list (POST)"""
        return self.client.call(module="shop_category", name="add_item_list", payload=kwargs)

    def add_shop_category(self, **kwargs):
        """v2.shop_category.add_shop_category (POST)"""
        return self.client.call(module="shop_category", name="add_shop_category", payload=kwargs)

    def delete_item_list(self, **kwargs):
        """v2.shop_category.delete_item_list (POST)"""
        return self.client.call(module="shop_category", name="delete_item_list", payload=kwargs)

    def delete_shop_category(self, **kwargs):
        """v2.shop_category.delete_shop_category (POST)"""
        return self.client.call(module="shop_category", name="delete_shop_category", payload=kwargs)

    def get_item_list(self, **kwargs):
        """v2.shop_category.get_item_list (GET)"""
        return self.client.call(module="shop_category", name="get_item_list", payload=kwargs)

    def get_shop_category_list(self, **kwargs):
        """v2.shop_category.get_shop_category_list (GET)"""
        return self.client.call(module="shop_category", name="get_shop_category_list", payload=kwargs)

    def update_shop_category(self, **kwargs):
        """v2.shop_category.update_shop_category (POST)"""
        return self.client.call(module="shop_category", name="update_shop_category", payload=kwargs)
