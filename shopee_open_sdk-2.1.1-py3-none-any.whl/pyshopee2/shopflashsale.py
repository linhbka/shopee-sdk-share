from .base import BaseModule


class ShopFlashSale(BaseModule):
    def add_shop_flash_sale_items(self, **kwargs):
        """v2.shop_flash_sale.add_shop_flash_sale_items (POST)"""
        return self.client.call(module="shop_flash_sale", name="add_shop_flash_sale_items", payload=kwargs)

    def create_shop_flash_sale(self, **kwargs):
        """v2.shop_flash_sale.create_shop_flash_sale (POST)"""
        return self.client.call(module="shop_flash_sale", name="create_shop_flash_sale", payload=kwargs)

    def delete_shop_flash_sale(self, **kwargs):
        """v2.shop_flash_sale.delete_shop_flash_sale (POST)"""
        return self.client.call(module="shop_flash_sale", name="delete_shop_flash_sale", payload=kwargs)

    def delete_shop_flash_sale_items(self, **kwargs):
        """v2.shop_flash_sale.delete_shop_flash_sale_items (POST)"""
        return self.client.call(module="shop_flash_sale", name="delete_shop_flash_sale_items", payload=kwargs)

    def get_item_criteria(self, **kwargs):
        """v2.shop_flash_sale.get_item_criteria (GET)"""
        return self.client.call(module="shop_flash_sale", name="get_item_criteria", payload=kwargs)

    def get_shop_flash_sale(self, **kwargs):
        """v2.shop_flash_sale.get_shop_flash_sale (GET)"""
        return self.client.call(module="shop_flash_sale", name="get_shop_flash_sale", payload=kwargs)

    def get_shop_flash_sale_items(self, **kwargs):
        """v2.shop_flash_sale.get_shop_flash_sale_items (GET)"""
        return self.client.call(module="shop_flash_sale", name="get_shop_flash_sale_items", payload=kwargs)

    def get_shop_flash_sale_list(self, **kwargs):
        """v2.shop_flash_sale.get_shop_flash_sale_list (GET)"""
        return self.client.call(module="shop_flash_sale", name="get_shop_flash_sale_list", payload=kwargs)

    def get_time_slot_id(self, **kwargs):
        """v2.shop_flash_sale.get_time_slot_id (GET)"""
        return self.client.call(module="shop_flash_sale", name="get_time_slot_id", payload=kwargs)

    def update_shop_flash_sale(self, **kwargs):
        """v2.shop_flash_sale.update_shop_flash_sale (POST)"""
        return self.client.call(module="shop_flash_sale", name="update_shop_flash_sale", payload=kwargs)

    def update_shop_flash_sale_items(self, **kwargs):
        """v2.shop_flash_sale.update_shop_flash_sale_items (POST)"""
        return self.client.call(module="shop_flash_sale", name="update_shop_flash_sale_items", payload=kwargs)
