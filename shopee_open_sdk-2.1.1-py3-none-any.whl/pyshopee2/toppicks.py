from .base import BaseModule


class Toppicks(BaseModule):
    def add_top_picks(self, **kwargs):
        """v2.top_picks.add_top_picks (POST)"""
        return self.client.call(module="top_picks", name="add_top_picks", payload=kwargs)

    def delete_top_picks(self, **kwargs):
        """v2.top_picks.delete_top_picks (POST)"""
        return self.client.call(module="top_picks", name="delete_top_picks", payload=kwargs)

    def get_top_picks_list(self, **kwargs):
        """v2.top_picks.get_top_picks_list (GET)"""
        return self.client.call(module="top_picks", name="get_top_picks_list", payload=kwargs)

    def update_top_picks(self, **kwargs):
        """v2.top_picks.update_top_picks (POST)"""
        return self.client.call(module="top_picks", name="update_top_picks", payload=kwargs)
