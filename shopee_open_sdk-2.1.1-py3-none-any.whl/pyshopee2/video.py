from .base import BaseModule


class Video(BaseModule):
    def delete_video(self, **kwargs):
        """v2.video.delete_video (POST)"""
        return self.client.call(module="video", name="delete_video", payload=kwargs)

    def edit_video_info(self, **kwargs):
        """v2.video.edit_video_info (POST)"""
        return self.client.call(module="video", name="edit_video_info", payload=kwargs)

    def get_cover_list(self, **kwargs):
        """v2.video.get_cover_list (GET)"""
        return self.client.call(module="video", name="get_cover_list", payload=kwargs)

    def get_metric_trend(self, **kwargs):
        """v2.video.get_metric_trend (GET)"""
        return self.client.call(module="video", name="get_metric_trend", payload=kwargs)

    def get_overview_performance(self, **kwargs):
        """v2.video.get_overview_performance (GET)"""
        return self.client.call(module="video", name="get_overview_performance", payload=kwargs)

    def get_prodcut_performance_list(self, **kwargs):
        """v2.video.get_prodcut_performance_list (GET)"""
        return self.client.call(module="video", name="get_prodcut_performance_list", payload=kwargs)

    def get_user_demographics(self, **kwargs):
        """v2.video.get_user_demographics (GET)"""
        return self.client.call(module="video", name="get_user_demographics", payload=kwargs)

    def get_video_detail(self, **kwargs):
        """v2.video.get_video_detail (GET)"""
        return self.client.call(module="video", name="get_video_detail", payload=kwargs)

    def get_video_detail_audience_distribution(self, **kwargs):
        """v2.video.get_video_detail_audience_distribution (GET)"""
        return self.client.call(module="video", name="get_video_detail_audience_distribution", payload=kwargs)

    def get_video_detail_metric_trend(self, **kwargs):
        """v2.video.get_video_detail_metric_trend (GET)"""
        return self.client.call(module="video", name="get_video_detail_metric_trend", payload=kwargs)

    def get_video_detail_performance(self, **kwargs):
        """v2.video.get_video_detail_performance (GET)"""
        return self.client.call(module="video", name="get_video_detail_performance", payload=kwargs)

    def get_video_detail_product_performance(self, **kwargs):
        """v2.video.get_video_detail_product_performance (GET)"""
        return self.client.call(module="video", name="get_video_detail_product_performance", payload=kwargs)

    def get_video_list(self, **kwargs):
        """v2.video.get_video_list (GET)"""
        return self.client.call(module="video", name="get_video_list", payload=kwargs)

    def get_video_performance_list(self, **kwargs):
        """v2.video.get_video_performance_list (GET)"""
        return self.client.call(module="video", name="get_video_performance_list", payload=kwargs)

    def post_video(self, **kwargs):
        """v2.video.post_video (POST)"""
        return self.client.call(module="video", name="post_video", payload=kwargs)
