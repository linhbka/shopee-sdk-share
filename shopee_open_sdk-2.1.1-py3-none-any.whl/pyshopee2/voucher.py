from .base import BaseModule


class Voucher(BaseModule):
    def add_voucher(self, **kwargs):
        """v2.voucher.add_voucher (POST)"""
        return self.client.call(module="voucher", name="add_voucher", payload=kwargs)

    def delete_voucher(self, **kwargs):
        """v2.voucher.delete_voucher (POST)"""
        return self.client.call(module="voucher", name="delete_voucher", payload=kwargs)

    def end_voucher(self, **kwargs):
        """v2.voucher.end_voucher (POST)"""
        return self.client.call(module="voucher", name="end_voucher", payload=kwargs)

    def get_voucher(self, **kwargs):
        """v2.voucher.get_voucher (GET)"""
        return self.client.call(module="voucher", name="get_voucher", payload=kwargs)

    def get_voucher_list(self, **kwargs):
        """v2.voucher.get_voucher_list (GET)"""
        return self.client.call(module="voucher", name="get_voucher_list", payload=kwargs)

    def update_voucher(self, **kwargs):
        """v2.voucher.update_voucher (POST)"""
        return self.client.call(module="voucher", name="update_voucher", payload=kwargs)
